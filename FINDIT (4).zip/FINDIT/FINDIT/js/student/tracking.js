/* Shared by the student's tracking page and the admin message view. */
// Show the messages between the student and the admin.
function thread(item) {
  const conversation = el("div", "thread");
  if (!item.messages.length) conversation.appendChild(el("p", "meta", "No messages yet."));
  item.messages.forEach((message) => {
    const bubble = el("div", "msg " + message.from);
    const sender = message.from === "admin" ? "Admin" : "Student";
    bubble.appendChild(el("small", "", sender + " | " + fmt(message.at, true)));
    bubble.appendChild(document.createTextNode(message.text));
    conversation.appendChild(bubble);
  });
  return conversation;
}

// Find a report using the reference number and Student ID entered by the student.
function findTrackedItem() {
  const reference = $("trackRef").value.trim().toLowerCase();
  const studentId = $("trackSid").value.trim().toLowerCase();
  return items.find((item) =>
    item.ref.toLowerCase() === reference && item.reporter.sid.toLowerCase() === studentId);
}

// Show a report's status, history, messages, and request options.
function renderTrack(item) {
  const result = $("trackResult");
  result.innerHTML = "";
  result.classList.remove("hidden");
  result.append(el("h3", "", item.name + " (" + item.ref + ")"), el("p", "", "Status: " + item.status));
  if (item.note) result.appendChild(el("p", "question-box", "Note from admin: " + item.note));
  const history = el("ul");
  item.history.forEach((event) => history.appendChild(el("li", "", event.label + " | " + fmt(event.at, true))));
  result.append(history, el("h3", "", "Messages"), thread(item));

  const reply = el("textarea");
  reply.rows = 2;
  reply.placeholder = "Ask the admin, for example: has a black wallet been found?";
  reply.id = "studentMsg";
  const sendButton = el("button", "primary", "Send message");
  sendButton.addEventListener("click", () => {
    const message = reply.value.trim();
    if (!message) return;
    item.messages.push({ from: "student", text: message, at: new Date().toISOString() });
    item.unread = true;
    save();
    renderTrack(item);
    say("Message sent to the admin.");
  });
  result.append(reply, sendButton);
  renderDeletionRequest(result, item);
}

// Refresh the report after another browser tab changes saved information.
function refreshTrackFromStorage() {
  const item = findTrackedItem();
  if (!item) {
    const result = $("trackResult");
    if (!result.classList.contains("hidden")) {
      result.classList.add("hidden");
      $("trackError").textContent = "This report is no longer available. Contact the admin if you did not request its deletion.";
    }
    return;
  }

  const replyDraft = $("studentMsg") ? $("studentMsg").value : "";
  const deletionDraft = $("deletionReason") ? $("deletionReason").value : "";
  renderTrack(item);
  $("studentMsg").value = replyDraft;
  if ($("deletionReason")) $("deletionReason").value = deletionDraft;
}

// Look up a report when the student submits the tracking form.
function track(e) {
  e.preventDefault();
  const item = findTrackedItem();
  $("trackError").textContent = item ? "" : "No report found. Check your reference code and Student ID.";
  if (item) renderTrack(item);
  else $("trackResult").classList.add("hidden");
}

