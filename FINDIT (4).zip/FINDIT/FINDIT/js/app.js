/* FindIt v7: Student report + Admin dashboard (localStorage only) */
const KEY = "findit_v7_items";
const SESSION = "findit_v7_admin";
const ADMIN_USER = "admin", ADMIN_PASS = "findit2026";   // demo login (simulation only)
const CATEGORIES = ["Bags", "Electronics", "ID and Cards", "Keys", "Wallet and Money", "Clothing", "Books and Stationery", "Others"];
const LOCATIONS = ["Main Gate", "Library", "Canteen", "Gymnasium", "V Building", "L Building", "Chapel", "Parking Area", "Others"];
const DEPTS = ["SITE", "SBA", "SIHM", "SOHS", "STE", "SOH", "SOE", "SOC"];
const STOP = ["the", "and", "with", "for", "from", "near", "was", "are", "has", "have", "left", "found", "lost", "this", "that", "item", "its", "small", "big"];
let items = [], tab = "lost", photoData = "", msgTimer = null;
// Find a page element by its ID.
const $ = (id) => document.getElementById(id);
const rf = $("reportForm");

/* ---------- helpers ---------- */
// Create a page element and optionally give it a class and text.
function el(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

// Check whether text looks like an email address.
function isEmail(value) {
  return typeof value === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

// Turn a saved date into a date people can read.
function fmt(iso, withTime) {
  const date = new Date(iso);
  if (isNaN(date)) return iso;
  const options = withTime
    ? { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }
    : { month: "short", day: "numeric", year: "numeric" };
  return date.toLocaleString("en-PH", options);
}

// Get today's date in the format used by the date field.
function today() {
  const date = new Date();
  date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
  return date.toISOString().slice(0, 10);
}

// Show a message on the page, then hide it after four seconds.
function say(text, kind) {
  const message = $("message");
  message.textContent = text;
  message.className = "message " + (kind || "ok");
  message.hidden = false;
  clearTimeout(msgTimer);
  msgTimer = setTimeout(() => { message.hidden = true; }, 4000);
}

// Add a list of choices to a dropdown menu.
function fill(select, options, firstLabel) {
  select.innerHTML = "";
  const firstOption = el("option", "", firstLabel);
  firstOption.value = "";
  select.appendChild(firstOption);
  options.forEach((option) => {
    const optionElement = el("option", "", option);
    optionElement.value = option;
    select.appendChild(optionElement);
  });
}

// Check whether this browser tab is logged in as the admin.
function isAdmin() { return sessionStorage.getItem(SESSION) === "1"; }

/* ---------- storage ---------- */
// Create example reports for a first-time visit.
function seed() {
  // Build one example report with the usual report fields.
  const makeSampleReport = (id, type, name, category, location, date, description, proof, reporter, status) => ({
    id,
    ref: "FI-000" + id,
    type,
    name,
    category,
    location,
    date,
    description,
    proof,
    photo: "",
    reporter,
    status,
    note: "",
    custody: "",
    messages: [],
    unread: false,
    history: [{
      label: type === "found" ? "Reported found" : "Reported lost",
      at: date + "T08:00:00.000Z"
    }]
  });
  return [
    makeSampleReport(1, "lost", "Black umbrella", "Others", "Library", "2026-11-03",
      "Black umbrella with a wooden handle.", "Initials JM carved on the handle",
      { name: "Juan Dela Cruz", sid: "2023-00123", dept: "SITE", block: "31-ITE-01", contact: "juan@example.com" },
      "Reported"),
    makeSampleReport(2, "found", "Black folding umbrella", "Others", "Library", "2026-11-04",
      "Small black folding umbrella found on a chair.", "Handle has carved initials",
      { name: "Maria Santos", sid: "2022-00456", dept: "SBA", block: "22-SBA-02", contact: "maria@example.com" },
      "Reported"),
    makeSampleReport(3, "found", "Student ID card", "ID and Cards", "Main Gate", "2026-11-05",
      "Student ID near the guard house.", "Name on the card starts with R",
      { name: "Pedro Reyes", sid: "2021-00789", dept: "SITE", block: "41-ITE-01", contact: "pedro@example.com" },
      "Reported")
  ];
}

// Correct old demo items that were mistakenly marked as already received.
function resetUnreceivedDemoReports() {
  const sampleReferences = ["FI-0002", "FI-0003"];
  const reportsToReset = items.filter((report) =>
    sampleReferences.includes(report.ref) &&
    report.type === "found" &&
    report.status === "Received at SAO" &&
    report.custody === "SAO Office" &&
    report.history &&
    report.history.length === 1 &&
    report.history[0].label === "Reported found"
  );
  reportsToReset.forEach((report) => {
    report.status = "Reported";
    report.custody = "";
  });
  if (reportsToReset.length) save();
}

// Read saved reports; create examples if this browser has none yet.
function load() {
  try {
    const savedItems = localStorage.getItem(KEY);
    if (savedItems === null) {
      items = seed();
      save();
    } else {
      items = JSON.parse(savedItems);
    }
    if (!Array.isArray(items)) throw new Error("Saved data is not a list.");
    resetUnreceivedDemoReports();
  } catch (error) {
    items = [];
    say("Saved data could not be read.", "bad");
  }
}

// Save the current reports in this browser.
function save() {
  try {
    localStorage.setItem(KEY, JSON.stringify(items));
  } catch (error) {
    say("Could not save. Storage may be full (try a smaller photo).", "bad");
  }
}

// Add a dated event to a report's history.
function log(item, label) { item.history.push({ label, at: new Date().toISOString() }); }

// Remove duplicate "possible match" events from a report's history.
function dedupeMatchEvents(item) {
  // Recognize older and newer ways a possible match was recorded.
  const isMatchEvent = (entry) => /^Possible match found(?:: .+)?(?: \(\d+%\))?$/.test(entry.label);
  const seen = new Set(), keep = new Set();
  for (let index = item.history.length - 1; index >= 0; index--) {
    const entry = item.history[index];
    if (!isMatchEvent(entry)) {
      keep.add(index);
      continue;
    }
    const key = entry.matchRef || "legacy";
    if (!seen.has(key)) {
      seen.add(key);
      keep.add(index);
    }
  }
  if (keep.size === item.history.length) return false;
  item.history = item.history.filter((entry, index) => keep.has(index));
  return true;
}

// Add a match to history only if that match is not already listed.
function logMatchOnce(item, match, score) {
  dedupeMatchEvents(item);
  if (item.history.some((entry) => entry.matchRef === match.ref)) return true;
  item.history.push({ label: "Possible match found: " + match.ref + " (" + score + "%)", matchRef: match.ref, at: new Date().toISOString() });
  return false;
}

/* ---------- views ---------- */
let current = "home";

// Clear the tracking form when leaving it.
function resetTrack() {
  $("trackRef").value = "";
  $("trackSid").value = "";
  $("trackError").textContent = "";
  $("trackResult").innerHTML = "";
  $("trackResult").classList.add("hidden");
}

// Clear the report form when leaving it.
function resetReport() {
  rf.reset();
  photoData = "";
  $("photo").value = "";
  $("photoPreview").classList.add("hidden");
  const fields = ["fullName", "studentId", "dept", "block", "contact", "name",
    "category", "location", "date", "description", "proof"];
  fields.forEach((fieldName) => showErr(fieldName, ""));
  setType();
}

// Clear private page data before moving to another screen.
function leave(previousView, nextView) {
  if (previousView === nextView) return;
  if (previousView === "track") resetTrack();
  if (previousView === "done") $("doneRef").textContent = "";
  if (previousView === "report" && nextView !== "done") resetReport();
  if (previousView === "login") {
    $("loginUser").value = "";
    $("loginPass").value = "";
    $("loginError").textContent = "";
  }
  if (previousView === "admin") {
    tab = "lost";
    $("search").value = "";
    $("fCategory").value = "";
    $("fLocation").value = "";
    $("sortBy").value = "newest";
    if ($("detail").open) $("detail").close();
  }
}

// Show the requested screen, sending logged-out admins to the login page.
function show(view) {
  if (view === "admin" && !isAdmin()) view = "login";
  leave(current, view);
  current = view;
  document.querySelectorAll('[id^="view-"]').forEach((section) => {
    section.classList.toggle("hidden", section.id !== "view-" + view);
  });
  $("appbar").classList.toggle("hidden", view === "home");
  $("homeButton").classList.toggle("hidden", view === "admin");
  $("logoutBtn").classList.toggle("hidden", view !== "admin");
  if (view === "admin") renderAdmin();
  window.scrollTo(0, 0);
}

/* ---------- start-up ---------- */
// Handle clicks on navigation, tabs, and report-detail buttons.
function handleAppClick(e) {
  const navigationButton = e.target.closest("[data-go]");
  if (navigationButton) show(navigationButton.dataset.go);

  const tabButton = e.target.closest("[data-tab]");
  if (tabButton) {
    tab = tabButton.dataset.tab;
    renderAdmin();
  }

  const closeDetail = e.target.closest("[data-close-detail]");
  if (closeDetail) {
    const detail = $("detail");
    if (detail.open) detail.close();
    renderAdmin();
    return;
  }

  const detailAction = e.target.closest("button[data-detail-section]");
  if (detailAction) openDetail(Number(detailAction.dataset.itemId), detailAction.dataset.detailSection);
}

// Set up the forms and buttons when the page first loads.
function init() {
  fill(rf.elements.category, CATEGORIES, "Select a category");
  fill(rf.elements.location, LOCATIONS, "Select a location");
  fill(rf.elements.dept, DEPTS, "Select school");
  fill($("fCategory"), CATEGORIES, "All categories");
  fill($("fLocation"), LOCATIONS, "All locations");
  rf.elements.date.max = today();
  load();
  setType();
  show(isAdmin() ? "admin" : "home");

  document.addEventListener("click", handleAppClick);
  rf.addEventListener("submit", submitReport);
  rf.addEventListener("focusout", (event) => {
    const fieldName = event.target.name;
    if (fieldName && fieldName !== "type" && rf.elements[fieldName]) {
      showErr(fieldName, check(fieldName));
    }
  });
  rf.querySelectorAll('input[name="type"]').forEach((radioButton) => {
    radioButton.addEventListener("change", setType);
  });
  $("photo").addEventListener("change", onPhoto);
  $("trackForm").addEventListener("submit", track);
  $("loginForm").addEventListener("submit", login);
  $("logoutBtn").addEventListener("click", () => {
    if (!confirm("Are you sure you want to log out?")) return;
    sessionStorage.removeItem(SESSION);
    show("home");
  });
  $("search").addEventListener("input", renderAdmin);
  ["fCategory", "fLocation", "sortBy"].forEach((filterId) => {
    $(filterId).addEventListener("change", renderAdmin);
  });
  $("clearFilters").addEventListener("click", () => {
    $("search").value = "";
    $("fCategory").value = "";
    $("fLocation").value = "";
    $("sortBy").value = "newest";
    renderAdmin();
  });
  $("detail").addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    event.preventDefault();
    $("detail").close();
    renderAdmin();
  });
  window.addEventListener("storage", (event) => {
    if (event.key !== KEY || event.newValue === null) return;
    load();
    if (current === "admin") refreshAdminFromStorage();
    else if (current === "track") refreshTrackFromStorage();
  });
}
document.addEventListener("DOMContentLoaded", init);