/* Admin deletion-request review */
// Permanently delete a report after the admin confirms.
function approveDeletionRequest(report, dialog) {
  if (!confirm("Permanently delete " + report.ref + " and all of its history? This cannot be undone.")) return;
  items = items.filter((item) => item.id !== report.id);
  save();
  dialog.close();
  renderAdmin();
  say("Report and history permanently deleted.");
}

// Record the admin's decision and any response to the student.
function denyDeletionRequest(report, responseInput) {
  const request = report.deletionRequest;
  request.status = "denied";
  request.decidedAt = new Date().toISOString();
  request.adminResponse = responseInput.value.trim();
  log(report, "Deletion request denied" + (request.adminResponse ? ": " + request.adminResponse : ""));
  save();
  renderAdmin();
  say("Deletion request denied. The student can see the decision when tracking the report.");
  openDetail(report.id);
}

// Show the student's request and the admin's review buttons.
function renderAdminDeletionRequest(dialog, report) {
  const request = report.deletionRequest;
  if (!request) return;
  dialog.appendChild(el("h3", "", "Deletion request"));
  dialog.appendChild(el("p", "meta", "Status: " + request.status + " | Submitted " + fmt(request.requestedAt, true)));
  dialog.appendChild(el("p", "question-box", "Student's reason: " + request.reason));
  if (request.status === "pending") {
    const responseInput = el("textarea");
    responseInput.rows = 2;
    responseInput.placeholder = "Optional response to the student if denying";
    const actions = el("div", "actions");
    const approveButton = el("button", "danger", "Approve and permanently delete");
    approveButton.addEventListener("click", () => approveDeletionRequest(report, dialog));
    const denyButton = el("button", "", "Deny request");
    denyButton.addEventListener("click", () => denyDeletionRequest(report, responseInput));
    actions.append(approveButton, denyButton);
    dialog.append(responseInput, actions);
  } else if (request.status === "denied") {
    dialog.appendChild(el("p", "meta", "Decision: denied " + fmt(request.decidedAt, true)));
    if (request.adminResponse) dialog.appendChild(el("p", "meta", "Admin response: " + request.adminResponse));
  }
}
