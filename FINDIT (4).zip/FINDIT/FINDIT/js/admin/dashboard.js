/* Admin login and dashboard */
// Check the admin login details and open the dashboard if they are correct.
function login(event) {
  event.preventDefault();
  const username = $("loginUser").value.trim();
  const password = $("loginPass").value;
  if (username !== ADMIN_USER || password !== ADMIN_PASS) {
    $("loginError").textContent = "Wrong username or password.";
    return;
  }
  sessionStorage.setItem(SESSION, "1");
  $("loginError").textContent = "";
  $("loginPass").value = "";
  show("admin");
}

// Work out how many days have passed since the report date.
function ageDays(report) {
  const reportDate = new Date(report.date + "T00:00:00");
  return Math.floor((Date.now() - reportDate) / 86400000);
}

// Show the dashboard numbers, tabs, and reports that match the filters.
function renderAdmin() {
  const openReports = items.filter((report) => report.status !== "Claimed");
  updateStats(openReports);
  updateTabButtons(openReports);

  const searchText = $("search").value.trim().toLowerCase();
  const category = $("fCategory").value;
  const location = $("fLocation").value;
  const reports = items.filter((report) => {
    let matchesTab;
    if (tab === "requests") matchesTab = report.deletionRequest && report.deletionRequest.status === "pending";
    else if (tab === "messages") matchesTab = report.messages.length > 0;
    else if (tab === "claimed") matchesTab = report.status === "Claimed";
    else matchesTab = report.type === tab && report.status !== "Claimed";

    const searchableText = [report.name, report.ref, report.reporter.name, report.reporter.sid, report.description]
      .join(" ").toLowerCase();
    const matchesSearch = !searchText || searchableText.includes(searchText);
    return matchesTab && matchesSearch &&
      (!category || report.category === category) &&
      (!location || report.location === location);
  });

  const sortBy = $("sortBy").value;
  reports.sort((first, second) => {
    if (sortBy === "name") return first.name.localeCompare(second.name);
    return sortBy === "oldest" ? first.id - second.id : second.id - first.id;
  });

  $("count").textContent = "Showing " + reports.length + " report" + (reports.length === 1 ? "" : "s");
  const feed = $("feed");
  feed.innerHTML = "";
  if (!reports.length) feed.appendChild(el("div", "empty", "Nothing to show here."));
  reports.forEach((report) => feed.appendChild(card(report)));
}

// Fill the four number boxes at the top of the dashboard.
function updateStats(openReports) {
  const tiles = [
    { type: "lost", count: openReports.filter((report) => report.type === "lost").length, label: "Open lost reports" },
    { type: "found", count: openReports.filter((report) => report.type === "found").length, label: "Found, waiting for owner" },
    { type: "claimed", count: items.length - openReports.length, label: "Claimed" },
    { type: "old", count: openReports.filter((report) => ageDays(report) >= 30).length, label: "Unclaimed 30+ days" }
  ];
  const stats = $("stats");
  stats.innerHTML = "";
  tiles.forEach((tileData) => {
    const tile = el("div", "tile " + tileData.type);
    tile.append(el("strong", "", String(tileData.count)), el("span", "", tileData.label));
    stats.appendChild(tile);
  });
}

// Update the names and report counts shown on the dashboard tabs.
function updateTabButtons(openReports) {
  const counts = {
    lost: openReports.filter((report) => report.type === "lost").length,
    found: openReports.filter((report) => report.type === "found").length,
    claimed: items.length - openReports.length,
    messages: items.filter((report) => report.messages.length > 0).length,
    requests: items.filter((report) => report.deletionRequest && report.deletionRequest.status === "pending").length
  };
  const labels = { lost: "Lost", found: "Found", claimed: "Claimed", messages: "Messages", requests: "Deletion requests" };
  document.querySelectorAll("#tabs button").forEach((button) => {
    button.classList.toggle("active", button.dataset.tab === tab);
    button.textContent = labels[button.dataset.tab] + " (" + counts[button.dataset.tab] + ")";
  });
}

// Refresh saved data and keep the open detail view if its report still exists.
function refreshAdminFromStorage() {
  const dialog = $("detail");
  const reportId = dialog.open ? Number(dialog.dataset.itemId) : 0;
  const section = dialog.dataset.detailSection || "view";
  renderAdmin();
  if (reportId && items.some((report) => report.id === reportId)) openDetail(reportId, section);
  else if (dialog.open) dialog.close();
}

// Build one report card with its details and action buttons.
function card(report) {
  const claimed = report.status === "Claimed";
  const reportCard = el("article", "card" + (claimed ? " claimed" : ""));
  const top = el("div", "card-top");
  const badgeText = claimed ? "CLAIMED" : report.type.toUpperCase();
  top.append(el("span", "badge " + (claimed ? "claimed" : report.type), badgeText), el("h3", "", report.name));
  if (report.unread) top.appendChild(el("span", "dot"));
  if (!claimed && ageDays(report) >= 30) top.appendChild(el("span", "badge stale", "30+ DAYS"));
  reportCard.appendChild(top);

  if (report.photo) {
    const photo = el("img", "thumb");
    photo.src = report.photo;
    photo.alt = "";
    reportCard.appendChild(photo);
  }
  reportCard.appendChild(el("div", "meta", report.ref + " | " + report.category + " | " + report.location + " | " + fmt(report.date)));
  reportCard.appendChild(el("div", "meta", "Reporter: " + report.reporter.name + " (" + report.reporter.sid + ", " + report.reporter.dept + " " + report.reporter.block + ")"));
  reportCard.appendChild(el("div", "custody", "Status: " + report.status + (report.custody ? " | Held at " + report.custody : "")));

  const actions = el("div", "card-actions");
  [["View", "view"], ["Matches", "matches"], ["Message", "message"]].forEach(([label, section]) => {
    const button = el("button", section === "view" ? "primary" : "", label);
    button.dataset.itemId = report.id;
    button.dataset.detailSection = section;
    actions.appendChild(button);
  });
  reportCard.appendChild(actions);
  return reportCard;
}
