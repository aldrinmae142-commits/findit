/* Admin report detail view and actions */
// Display report details as a list of labels and values.
function kv(parent, pairs) { const dl = el("dl", "kv"); pairs.forEach(([k, v]) => { dl.appendChild(el("dt", "", k)); dl.appendChild(el("dd", "", v)); }); parent.appendChild(dl); }

// Show the report information that admins need to review.
function renderReportSummary(dialog, report) {
  renderDetailTitle(dialog, report);
  if (report.photo) {
    const photo = el("img", "photo-preview");
    photo.src = report.photo;
    photo.alt = "Photo of " + report.name;
    dialog.appendChild(photo);
  }
  const details = [["Type", report.type.toUpperCase()], ["Status", report.status], ["Category", report.category],
    ["Location", report.location], ["Date", fmt(report.date)], ["Description", report.description],
    ["Proof details", report.proof]];
  if (report.type === "found") details.push(["Held at", report.custody || "Not yet received"]);
  details.push(["Reporter", report.reporter.name + " | " + report.reporter.sid + " | " + report.reporter.dept + " " + report.reporter.block],
    ["Email", report.reporter.contact || "Not provided"]);
  kv(dialog, details);
}

// Show the report's name and reference number at the top of the dialog.
function renderDetailTitle(dialog, report) {
  dialog.appendChild(el("h2", "", report.name + " (" + report.ref + ")"));
}

// Let the admin write a note that the student can see while tracking.
function renderAdminNote(dialog, report) {
  dialog.appendChild(el("h3", "", "Note for the student (shown in Track a Report)"));
  const noteInput = el("textarea");
  noteInput.rows = 2;
  noteInput.value = report.note;
  const saveButton = el("button", "", "Save note");
  saveButton.addEventListener("click", () => {
    report.note = noteInput.value.trim();
    log(report, "Note updated");
    save();
    say("Note saved.");
    openDetail(report.id);
  });
  dialog.append(noteInput, saveButton);
}

// Let the admin mark a found item as received by the SAO office.
function renderCustodyAction(dialog, report) {
  if (report.type !== "found") return;
  const isReceived = Boolean(report.custody);
  const buttonLabel = isReceived ? "Received at SAO" : "Mark as received at SAO";
  const receiveButton = el("button", isReceived ? "" : "primary", buttonLabel);
  if (isReceived) {
    receiveButton.disabled = true;
    dialog.appendChild(receiveButton);
    return;
  }

  receiveButton.addEventListener("click", () => {
    report.custody = "SAO Office";
    report.status = "Received at SAO";
    log(report, "Received at SAO");
    save();
    renderAdmin();
    openDetail(report.id);
  });
  dialog.appendChild(receiveButton);
}

// Show the checks the admin must complete before releasing a lost item.
function renderClaimControls(dialog, report) {
  if (report.type !== "lost") return;
  if (report.status === "Claimed") {
    dialog.appendChild(el("p", "meta", "Claimed by " + (report.claimedBy || "n/a") + " on " + fmt(report.claimedAt || report.date, true)));
    return;
  }
  dialog.appendChild(el("h3", "", "Release to owner (claim)"));
  const claimHint = "Expected owner: " + report.reporter.name + " | Student ID: " + report.reporter.sid;
  dialog.appendChild(el("p", "question-box", claimHint));
  const claimantName = el("input"); claimantName.placeholder = "Claimant full name";
  const claimantId = el("input"); claimantId.placeholder = "Claimant Student ID";
  const checklist = el("div", "checks");
  const checks = ["Claimant matches the student on the lost report", "Proof details match the item", "School ID was checked"].map((label) => {
    const labelElement = el("label");
    const checkbox = el("input");
    checkbox.type = "checkbox";
    labelElement.append(checkbox, document.createTextNode(label));
    checklist.appendChild(labelElement);
    return checkbox;
  });
  const claimButton = el("button", "primary", "Mark as claimed");
  claimButton.addEventListener("click", () => {
    if (claimantName.value.trim().length < 3 || claimantId.value.trim().length < 5) {
      say("Enter the claimant's name and Student ID.", "bad");
      return;
    }
    if (!checks.every((checkbox) => checkbox.checked)) {
      say("Complete the verification checklist first.", "bad");
      return;
    }
    report.status = "Claimed";
    report.claimedBy = claimantName.value.trim() + " (" + claimantId.value.trim() + ")";
    report.claimedAt = new Date().toISOString();
    log(report, "Claimed by " + report.claimedBy);
    save();
    say(report.name + " marked as claimed.");
    dialog.close();
    renderAdmin();
  });
  dialog.append(claimantName, claimantId, checklist, claimButton);
}

// Show the report's history of important events.
function renderTimeline(dialog, report) {
  dialog.appendChild(el("h3", "", "Timeline"));
  const timeline = el("ul");
  report.history.forEach((event) => timeline.appendChild(el("li", "", event.label + " | " + fmt(event.at, true))));
  dialog.appendChild(timeline);
}

// Add the delete and close buttons to the full report view.
function renderDetailActions(dialog, report) {
  const actions = el("div", "actions");
  const deleteButton = el("button", "danger", "Delete report");
  deleteButton.addEventListener("click", () => {
    if (!confirm("Delete " + report.ref + "? This cannot be undone.")) return;
    items = items.filter((item) => item.id !== report.id);
    save();
    dialog.close();
    renderAdmin();
    say("Report deleted.");
  });
  actions.appendChild(deleteButton);
  renderDialogCloseAction(actions);
  dialog.appendChild(actions);
}

// Create a button that closes the report dialog.
function renderDialogCloseAction(parent) {
  const closeButton = el("button", "", "Close");
  closeButton.type = "button";
  closeButton.dataset.closeDetail = "true";
  parent.appendChild(closeButton);
}

// Add a close button to the Matches or Message section.
function renderSectionCloseAction(dialog) {
  const actions = el("div", "actions");
  renderDialogCloseAction(actions);
  dialog.appendChild(actions);
}

// Open a report in View, Matches, or Message mode.
function openDetail(reportId, section) {
  const report = items.find((item) => item.id === reportId);
  if (!report) return;
  let changed = false;
  if (report.type === "lost" && dedupeMatchEvents(report)) changed = true;
  if (report.unread) { report.unread = false; changed = true; }
  if (changed) save();

  const dialog = $("detail");
  dialog.innerHTML = "";
  dialog.dataset.itemId = String(reportId);
  const activeSection = section || "view";
  dialog.dataset.detailSection = activeSection;
  if (activeSection === "matches") {
    renderDetailTitle(dialog, report);
    renderPossibleMatches(dialog, report, matchesFor(report));
    renderSectionCloseAction(dialog);
  } else if (activeSection === "message") {
    renderDetailTitle(dialog, report);
    renderMessages(dialog, report);
    renderSectionCloseAction(dialog);
  } else {
    renderReportSummary(dialog, report);
    renderAdminNote(dialog, report);
    renderAdminDeletionRequest(dialog, report);
    renderCustodyAction(dialog, report);
    renderClaimControls(dialog, report);
    renderTimeline(dialog, report);
    renderDetailActions(dialog, report);
  }
  if (!dialog.open) dialog.showModal();
}
