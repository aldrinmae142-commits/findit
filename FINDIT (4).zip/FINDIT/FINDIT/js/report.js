/* Student report form */
// Change the field labels based on whether the student lost or found an item.
function setType() {
  const isFoundReport = rf.elements.type.value === "found";
  $("locationLabel").textContent = isFoundReport ? "Found at" : "Last seen at";
  $("dateLabel").textContent = isFoundReport ? "Date found" : "Date lost";
}

// Check one form field and return its error message, if it is invalid.
function check(fieldName) {
  const value = rf.elements[fieldName].value.trim();
  const rules = {
    fullName: [value.length >= 5, "Enter your full name."],
    studentId: [/^\d{2}-\d{4}-\d{3}$/.test(value), "Use the Student ID format 00-0000-000."],
    dept: [value !== "", "Choose your school."],
    block: [/^[\w-]{5,}$/.test(value), "Enter your block, for example 31-ITE-01."],
    contact: [isEmail(value), "Enter a valid email address."],
    name: [value.length >= 2, "Enter the item name."],
    category: [value !== "", "Choose a category."],
    location: [value !== "", "Choose a location."],
    date: [value !== "" && value <= today(), "Choose a valid date (not in the future)."],
    description: [value.length >= 10, "Describe the item (at least 10 characters)."],
    proof: [value.length >= 5, "Add proof details for the admin (at least 5 characters)."]
  };
  const rule = rules[fieldName];
  return rule && !rule[0] ? rule[1] : "";
}

// Show or clear the error message below a form field.
function showErr(fieldName, message) {
  const errorMessage = document.querySelector('.error[data-for="' + fieldName + '"]');
  if (errorMessage) errorMessage.textContent = message;
  rf.elements[fieldName].classList.toggle("invalid", message !== "");
}

// Check all required fields before the report is submitted.
function validateForm() {
  let isValid = true;
  const fields = ["fullName", "studentId", "dept", "block", "contact", "name",
    "category", "location", "date", "description", "proof"];
  fields.forEach((fieldName) => {
    const errorMessage = check(fieldName);
    showErr(fieldName, errorMessage);
    if (errorMessage) isValid = false;
  });
  return isValid;
}

// Create the next reference number after the last saved report.
function nextRef() {
  const highestNumber = items.reduce((highest, report) => {
    const number = parseInt(report.ref.slice(3), 10) || 0;
    return Math.max(highest, number);
  }, 0);
  return "FI-" + String(highestNumber + 1).padStart(4, "0");
}

// Validate the form, save the report, and show its reference number.
function submitReport(e) {
  e.preventDefault();
  if (!validateForm()) { say("Please fix the highlighted fields.", "bad"); return; }
  // Read a form value without extra spaces at the beginning or end.
  const fieldValue = (fieldName) => rf.elements[fieldName].value.trim();
  const type = rf.elements.type.value;
  const now = new Date().toISOString();
  const item = {
    id: Date.now(),
    ref: nextRef(),
    type,
    name: fieldValue("name"),
    category: fieldValue("category"),
    location: fieldValue("location"),
    date: fieldValue("date"),
    description: fieldValue("description"),
    proof: fieldValue("proof"),
    photo: photoData,
    reporter: {
      name: fieldValue("fullName"),
      sid: fieldValue("studentId"),
      dept: fieldValue("dept"),
      block: fieldValue("block"),
      contact: fieldValue("contact")
    },
    status: "Reported",
    note: "",
    custody: "",
    messages: [],
    unread: false,
    history: [{ label: type === "found" ? "Reported found" : "Reported lost", at: now }]
  };
  items.unshift(item);
  save();
  $("doneRef").textContent = item.ref;
  rf.reset();
  photoData = "";
  $("photoPreview").classList.add("hidden");
  setType();
  show("done");
}

// Resize the selected photo and show the smaller version in the form.
async function onPhoto(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    say("Please choose an image file.", "bad"); event.target.value = ""; return;
  }

  const image = await createImageBitmap(file).catch(() => null);
  if (!image) {
    say("Could not read this image. Please choose another.", "bad"); event.target.value = ""; return;
  }

  const scale = Math.min(1, 480 / Math.max(image.width, image.height));
  const canvas = document.createElement("canvas");
  canvas.width = image.width * scale; canvas.height = image.height * scale;
  canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
  image.close();
  photoData = canvas.toDataURL("image/jpeg", 0.7);
  const preview = $("photoPreview");
  preview.src = photoData; preview.classList.remove("hidden");
}

