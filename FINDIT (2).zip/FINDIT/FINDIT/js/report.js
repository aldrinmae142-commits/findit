/* Lost and found report workflow */
/* ---------- FEATURE 1: report form (student) ---------- */
function setType() { const f = rf.elements.type.value === "found";
  $("locationLabel").textContent = f ? "Found at" : "Last seen at"; $("dateLabel").textContent = f ? "Date found" : "Date lost"; }
function check(n) {
  const v = rf.elements[n].value.trim();
  const rules = { fullName: [v.length >= 5, "Enter your full name."], studentId: [/^[\w-]{5,}$/.test(v), "Enter a valid Student ID."],
    dept: [v !== "", "Choose your school."], block: [/^[\w-]{5,}$/.test(v), "Enter your block, for example 31-ITE-01."],
    contact: [isEmail(v), "Enter a valid email address."],
    name: [v.length >= 2, "Enter the item name."], category: [v !== "", "Choose a category."], location: [v !== "", "Choose a location."],
    date: [v !== "" && v <= today(), "Choose a valid date (not in the future)."],
    description: [v.length >= 10, "Describe the item (at least 10 characters)."], proof: [v.length >= 5, "Add proof details for the admin (at least 5 characters)."] };
  return rules[n] && !rules[n][0] ? rules[n][1] : "";
}
function showErr(n, m) { const s = document.querySelector('.error[data-for="' + n + '"]'); if (s) s.textContent = m; rf.elements[n].classList.toggle("invalid", m !== ""); }
function validateForm() { let ok = true;
  ["fullName", "studentId", "dept", "block", "contact", "name", "category", "location", "date", "description", "proof"].forEach((n) => { const m = check(n); showErr(n, m); if (m) ok = false; });
  return ok; }
function nextRef() { const max = items.reduce((m, i) => Math.max(m, parseInt(i.ref.slice(3), 10) || 0), 0); return "FI-" + String(max + 1).padStart(4, "0"); }
function submitReport(e) {
  e.preventDefault();
  if (!validateForm()) { say("Please fix the highlighted fields.", "bad"); return; }
  const g = (n) => rf.elements[n].value.trim(), type = rf.elements.type.value, now = new Date().toISOString();
  const item = { id: Date.now(), ref: nextRef(), type, name: g("name"), category: g("category"), location: g("location"), date: g("date"),
    description: g("description"), proof: g("proof"), photo: photoData,
    reporter: { name: g("fullName"), sid: g("studentId"), dept: g("dept"), block: g("block"), contact: g("contact") },
    status: type === "found" ? "Reported" : "Reported", note: "", custody: "", messages: [], unread: false,
    history: [{ label: type === "found" ? "Reported found" : "Reported lost", at: now }] };
  items.unshift(item); save();
  $("doneRef").textContent = item.ref; rf.reset(); photoData = ""; $("photoPreview").classList.add("hidden"); setType(); show("done");
}
function onPhoto(e) {   // resize to max 480px and store as Base64
  const file = e.target.files[0]; if (!file) return;
  if (!file.type.startsWith("image/")) { say("Please choose an image file.", "bad"); e.target.value = ""; return; }
  const reader = new FileReader();
  reader.onload = () => { const img = new Image(); img.onload = () => {
    const s = Math.min(1, 480 / Math.max(img.width, img.height)), c = document.createElement("canvas");
    c.width = img.width * s; c.height = img.height * s; c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    photoData = c.toDataURL("image/jpeg", 0.7); const p = $("photoPreview"); p.src = photoData; p.classList.remove("hidden"); };
    img.src = reader.result; };
  reader.readAsDataURL(file);
}

