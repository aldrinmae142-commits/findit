/* FindIt v7: Student report + Admin dashboard (localStorage only) */
const KEY = "findit_v7_items", SESSION = "findit_v7_admin";
const ADMIN_USER = "admin", ADMIN_PASS = "findit2026";   // demo login (simulation only)
const CATEGORIES = ["Bags", "Electronics", "ID and Cards", "Keys", "Wallet and Money", "Clothing", "Books and Stationery", "Others"];
const LOCATIONS = ["Main Gate", "Library", "Canteen", "Gymnasium", "V Building", "L Building", "Chapel", "Parking Area", "Others"];
const DEPTS = ["SITE", "SBA", "SIHM", "SOHS", "STE", "SOH", "SOE", "SOC"];
const STOP = ["the", "and", "with", "for", "from", "near", "was", "are", "has", "have", "left", "found", "lost", "this", "that", "item", "its", "small", "big"];
let items = [], tab = "lost", photoData = "", msgTimer = null;
const $ = (id) => document.getElementById(id);
const rf = $("reportForm");

/* ---------- helpers ---------- */
function el(tag, cls, text) { const n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined) n.textContent = text; return n; }
function isEmail(value) { return typeof value === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value); }
function fmt(iso, withTime) { const d = new Date(iso); if (isNaN(d)) return iso;
  return d.toLocaleString("en-PH", withTime ? { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" } : { month: "short", day: "numeric", year: "numeric" }); }
function today() { const n = new Date(); n.setMinutes(n.getMinutes() - n.getTimezoneOffset()); return n.toISOString().slice(0, 10); }
function say(text, kind) { const b = $("message"); b.textContent = text; b.className = "message " + (kind || "ok"); b.hidden = false;
  clearTimeout(msgTimer); msgTimer = setTimeout(() => { b.hidden = true; }, 4000); }
function fill(sel, list, first) { sel.innerHTML = ""; const f = el("option", "", first); f.value = ""; sel.appendChild(f);
  list.forEach((o) => { const x = el("option", "", o); x.value = o; sel.appendChild(x); }); }
function isAdmin() { return sessionStorage.getItem(SESSION) === "1"; }

/* ---------- storage ---------- */
function seed() {
  const mk = (id, type, name, cat, loc, date, desc, proof, who, status) => ({ id, ref: "FI-000" + id, type, name, category: cat, location: loc, date,
    description: desc, proof, photo: "", reporter: who, status, note: "", custody: type === "found" ? "SAO Office" : "", messages: [], unread: false,
    history: [{ label: type === "found" ? "Reported found" : "Reported lost", at: date + "T08:00:00.000Z" }] });
  return [
    mk(1, "lost", "Black umbrella", "Others", "Library", "2026-11-03", "Black umbrella with a wooden handle.", "Initials JM carved on the handle",
      { name: "Juan Dela Cruz", sid: "2023-00123", dept: "SITE", block: "31-ITE-01", contact: "juan@example.com" }, "Reported"),
    mk(2, "found", "Black folding umbrella", "Others", "Library", "2026-11-04", "Small black folding umbrella found on a chair.", "Handle has carved initials",
      { name: "Maria Santos", sid: "2022-00456", dept: "SBA", block: "22-SBA-02", contact: "maria@example.com" }, "Received at SAO"),
    mk(3, "found", "Student ID card", "ID and Cards", "Main Gate", "2026-11-05", "Student ID near the guard house.", "Name on the card starts with R",
      { name: "Pedro Reyes", sid: "2021-00789", dept: "SITE", block: "41-ITE-01", contact: "pedro@example.com" }, "Received at SAO")];
}
function load() {
  try { const raw = localStorage.getItem(KEY); if (raw === null) { items = seed(); save(); } else items = JSON.parse(raw);
    if (!Array.isArray(items)) throw 0; } catch (e) { items = []; say("Saved data could not be read.", "bad"); }
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(items)); } catch (e) { say("Could not save. Storage may be full (try a smaller photo).", "bad"); } }
function log(item, label) { item.history.push({ label, at: new Date().toISOString() }); }
function dedupeMatchEvents(item) {
  const isMatchEvent = (entry) => /^Possible match found(?:: .+)?(?: \(\d+%\))?$/.test(entry.label);
  const seen = new Set(), keep = new Set();
  for (let index = item.history.length - 1; index >= 0; index--) {
    const entry = item.history[index];
    if (!isMatchEvent(entry)) { keep.add(index); continue; }
    const key = entry.matchRef || "legacy";
    if (!seen.has(key)) { seen.add(key); keep.add(index); }
  }
  if (keep.size === item.history.length) return false;
  item.history = item.history.filter((entry, index) => keep.has(index));
  return true;
}
function logMatchOnce(item, match, score) {
  dedupeMatchEvents(item);
  if (item.history.some((entry) => entry.matchRef === match.ref)) return true;
  item.history.push({ label: "Possible match found: " + match.ref + " (" + score + "%)", matchRef: match.ref, at: new Date().toISOString() });
  return false;
}

/* ---------- views ---------- */
let current = "home";
function resetTrack() { $("trackRef").value = ""; $("trackSid").value = ""; $("trackError").textContent = ""; $("trackResult").innerHTML = ""; $("trackResult").classList.add("hidden"); }
function resetReport() {
  rf.reset(); photoData = ""; $("photo").value = ""; $("photoPreview").classList.add("hidden");
  ["fullName", "studentId", "dept", "block", "contact", "name", "category", "location", "date", "description", "proof"].forEach((n) => showErr(n, "")); setType();
}
function leave(prev, next) {   // clear personal data so the next student never sees it
  if (prev === next) return;
  if (prev === "track") resetTrack();
  if (prev === "done") $("doneRef").textContent = "";
  if (prev === "report" && next !== "done") resetReport();
  if (prev === "login") { $("loginUser").value = ""; $("loginPass").value = ""; $("loginError").textContent = ""; }
  if (prev === "admin") { tab = "lost"; $("search").value = ""; $("fCategory").value = ""; $("fLocation").value = ""; $("sortBy").value = "newest"; if ($("detail").open) $("detail").close(); }
}
function show(view) {
  if (view === "admin" && !isAdmin()) view = "login";
  leave(current, view); current = view;
  document.querySelectorAll('[id^="view-"]').forEach((s) => s.classList.toggle("hidden", s.id !== "view-" + view));
  $("appbar").classList.toggle("hidden", view === "home");
  if (view === "admin") renderAdmin();
  window.scrollTo(0, 0);
}

/* ---------- start-up ---------- */
function handleAppClick(e) {
  const go = e.target.closest("[data-go]"); if (go) show(go.dataset.go);
  const tabButton = e.target.closest("[data-tab]"); if (tabButton) { tab = tabButton.dataset.tab; renderAdmin(); }
  const closeDetail = e.target.closest("[data-close-detail]");
  if (closeDetail) {
    const detail = $("detail");
    if (detail.open) detail.close();
    renderAdmin();
    return;
  }
  const detailAction = e.target.closest("button[data-detail-section]");
  if (detailAction) openDetail(Number(detailAction.dataset.itemId), detailAction.dataset.detailSection);
}

function init() {
  fill(rf.elements.category, CATEGORIES, "Select a category"); fill(rf.elements.location, LOCATIONS, "Select a location"); fill(rf.elements.dept, DEPTS, "Select school");
  fill($("fCategory"), CATEGORIES, "All categories"); fill($("fLocation"), LOCATIONS, "All locations");
  rf.elements.date.max = today(); load(); setType(); show(isAdmin() ? "admin" : "home");
  document.addEventListener("click", handleAppClick);
  rf.addEventListener("submit", submitReport);
  rf.addEventListener("focusout", (e) => { const n = e.target.name; if (n && n !== "type" && rf.elements[n]) showErr(n, check(n)); });
  rf.querySelectorAll('input[name="type"]').forEach((r) => r.addEventListener("change", setType));
  $("photo").addEventListener("change", onPhoto);
  $("trackForm").addEventListener("submit", track);
  $("loginForm").addEventListener("submit", login);
  $("logoutBtn").addEventListener("click", () => { sessionStorage.removeItem(SESSION); show("home"); });
  $("search").addEventListener("input", renderAdmin);
  ["fCategory", "fLocation", "sortBy"].forEach((id) => $(id).addEventListener("change", renderAdmin));
  $("clearFilters").addEventListener("click", () => { $("search").value = ""; $("fCategory").value = ""; $("fLocation").value = ""; $("sortBy").value = "newest"; renderAdmin(); });
  $("detail").addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); $("detail").close(); renderAdmin(); } });
  window.addEventListener("storage", (e) => {
    if (e.key !== KEY || e.newValue === null) return;
    load();
    if (current === "admin") refreshAdminFromStorage();
    else if (current === "track") refreshTrackFromStorage();
  });
}
document.addEventListener("DOMContentLoaded", init);