/* Report lookup and student messaging */
/* ---------- student: track a report + messages ---------- */
function thread(item) { const t = el("div", "thread");
  if (!item.messages.length) t.appendChild(el("p", "meta", "No messages yet."));
  item.messages.forEach((m) => { const b = el("div", "msg " + m.from); b.appendChild(el("small", "", (m.from === "admin" ? "Admin" : "Student") + " | " + fmt(m.at, true))); b.appendChild(document.createTextNode(m.text)); t.appendChild(b); });
  return t; }
function renderTrack(item) {
  const box = $("trackResult"); box.innerHTML = ""; box.classList.remove("hidden");
  box.appendChild(el("h3", "", item.name + " (" + item.ref + ")"));
  box.appendChild(el("p", "", "Status: " + item.status));
  if (item.note) box.appendChild(el("p", "question-box", "Note from admin: " + item.note));
  const ul = el("ul"); item.history.forEach((h) => ul.appendChild(el("li", "", h.label + " | " + fmt(h.at, true)))); box.appendChild(ul);
  box.appendChild(el("h3", "", "Messages")); box.appendChild(thread(item));
  const ta = el("textarea"); ta.rows = 2; ta.placeholder = "Ask the admin, for example: has a black wallet been found?"; ta.id = "studentMsg";
  const btn = el("button", "primary", "Send message");
  btn.addEventListener("click", () => { const t = ta.value.trim(); if (!t) return;
    item.messages.push({ from: "student", text: t, at: new Date().toISOString() }); item.unread = true; save(); renderTrack(item); say("Message sent to the admin."); });
  box.append(ta, btn);
  renderDeletionRequest(box, item);
}
function refreshTrackFromStorage() {
  const ref = $("trackRef").value.trim().toLowerCase(), sid = $("trackSid").value.trim().toLowerCase();
  const item = items.find((i) => i.ref.toLowerCase() === ref && i.reporter.sid.toLowerCase() === sid);
  if (!item) {
    if (!$("trackResult").classList.contains("hidden")) {
      $("trackResult").classList.add("hidden");
      $("trackError").textContent = "This report is no longer available. Contact the admin if you did not request its deletion.";
    }
    return;
  }
  const draft = $("studentMsg") ? $("studentMsg").value : "";
  const deletionDraft = $("deletionReason") ? $("deletionReason").value : "";
  renderTrack(item);
  $("studentMsg").value = draft;
  if ($("deletionReason")) $("deletionReason").value = deletionDraft;
}
function track(e) {
  e.preventDefault();
  const ref = $("trackRef").value.trim().toLowerCase(), sid = $("trackSid").value.trim().toLowerCase();
  const item = items.find((i) => i.ref.toLowerCase() === ref && i.reporter.sid.toLowerCase() === sid);
  $("trackError").textContent = item ? "" : "No report found. Check your reference code and Student ID.";
  if (item) renderTrack(item); else $("trackResult").classList.add("hidden");
}

