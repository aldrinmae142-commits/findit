/* Student deletion request workflow */
function renderDeletionRequest(box, item) {
  if (item.type !== "lost") return;
  box.appendChild(el("h3", "", "Request report deletion"));
  const request = item.deletionRequest;
  if (request && request.status === "pending") {
    box.appendChild(el("p", "question-box", "Your request was sent " + fmt(request.requestedAt, true) +
      " and is waiting for admin review. Reason: " + request.reason));
    return;
  }
  if (request && request.status === "denied") {
    box.appendChild(el("p", "question-box", "Your previous request was denied." +
      (request.adminResponse ? " Admin response: " + request.adminResponse : "") + " You may submit another request below."));
  }
  const label = el("label", "", "Reason for deletion"); label.htmlFor = "deletionReason";
  const reason = el("textarea"); reason.id = "deletionReason"; reason.rows = 2; reason.maxLength = 500;
  reason.placeholder = "Explain why this lost report should be deleted.";
  const requestButton = el("button", "danger", "Submit deletion request");
  requestButton.addEventListener("click", () => {
    const text = reason.value.trim();
    if (text.length < 10) { say("Please provide a reason of at least 10 characters.", "bad"); return; }
    item.deletionRequest = { status: "pending", reason: text, requestedAt: new Date().toISOString(), adminResponse: "" };
    item.unread = true; log(item, "Deletion request submitted: " + text); save(); renderTrack(item);
    say("Deletion request sent to the admin.");
  });
  box.append(label, reason, requestButton);
}
