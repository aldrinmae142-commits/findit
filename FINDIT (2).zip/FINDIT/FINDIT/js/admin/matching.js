/* Admin lost/found matching and comparison */
const MATCH_SCORE_WEIGHTS = {
  category: 30,
  sharedKeywords: 35,
  location: 20,
  withinThreeDays: 15,
  withinSevenDays: 7.5
};
const MIN_MATCH_SCORE = 40;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;

function keywordsFor(report) {
  const words = (report.name + " " + report.description).toLowerCase().split(/[^a-z0-9]+/);
  return new Set(words.filter((word) => word.length >= 3 && !STOP.includes(word)));
}

function keywordOverlapScore(lostReport, foundReport) {
  const lostKeywords = keywordsFor(lostReport);
  const foundKeywords = keywordsFor(foundReport);
  if (!lostKeywords.size || !foundKeywords.size) return 0;

  let sharedKeywordCount = 0;
  lostKeywords.forEach((keyword) => {
    if (foundKeywords.has(keyword)) sharedKeywordCount++;
  });
  const smallerKeywordCount = Math.min(lostKeywords.size, foundKeywords.size);
  return (sharedKeywordCount / smallerKeywordCount) * MATCH_SCORE_WEIGHTS.sharedKeywords;
}

function dateProximityScore(lostReport, foundReport) {
  const daysApart = Math.abs(new Date(lostReport.date) - new Date(foundReport.date)) / MILLISECONDS_PER_DAY;
  if (daysApart <= 3) return MATCH_SCORE_WEIGHTS.withinThreeDays;
  if (daysApart <= 7) return MATCH_SCORE_WEIGHTS.withinSevenDays;
  return 0;
}

function computeScore(lostReport, foundReport) {
  const categoryScore = lostReport.category === foundReport.category ? MATCH_SCORE_WEIGHTS.category : 0;
  const keywordScore = keywordOverlapScore(lostReport, foundReport);
  const locationScore = lostReport.location === foundReport.location ? MATCH_SCORE_WEIGHTS.location : 0;
  const dateScore = dateProximityScore(lostReport, foundReport);
  return Math.round(categoryScore + keywordScore + locationScore + dateScore);
}

function matchesFor(report) {
  const matchingType = report.type === "lost" ? "found" : "lost";
  return items
    .filter((item) => item.type === matchingType && item.status !== "Claimed")
    .map((item) => ({
      item,
      score: report.type === "lost" ? computeScore(report, item) : computeScore(item, report)
    }))
    .filter((match) => match.score >= MIN_MATCH_SCORE)
    .sort((left, right) => right.score - left.score);
}

function renderComparisonSide(comparison, report, heading) {
  const side = el("section", "compare-side");
  side.appendChild(el("h4", "", heading));
  if (report.photo) {
    const photo = el("img", "compare-photo");
    photo.src = report.photo;
    photo.alt = "Photo of " + report.name;
    side.appendChild(photo);
  } else side.appendChild(el("div", "compare-no-photo", "No photo provided"));
  side.appendChild(el("strong", "compare-name", report.name + " (" + report.ref + ")"));
  const details = [["Category", report.category], ["Location", report.location], ["Date", fmt(report.date)],
    ["Description", report.description], ["Proof details", report.proof || "Not provided"]];
  if (report.type === "lost") details.unshift(["Student name", report.reporter.name], ["Student ID", report.reporter.sid]);
  kv(side, details);
  comparison.appendChild(side);
}

function notifyLostReportOwner(lostReport, foundReport, score) {
  const alreadyRecorded = logMatchOnce(lostReport, foundReport, score);
  lostReport.status = "Possible match found";
  lostReport.note = "A possible match was found. Please visit the SAO office with your school ID.";
  save();
  say(alreadyRecorded ? "This match is already on the timeline." :
    "Match saved. The student can see the update in Track a Report.");
  openDetail(lostReport.id, "matches");
}

function renderPossibleMatches(dialog, report, matches) {
  dialog.appendChild(el("h3", "", "Possible matches (40% and above)"));
  if (!matches.length) {
    dialog.appendChild(el("p", "meta", "No possible matches yet."));
    return;
  }
  matches.forEach((match) => {
    const matchCard = el("div", "match");
    const matchHeader = el("div", "match-top");
    matchHeader.appendChild(el("span", "", match.item.name + " (" + match.item.ref + ")"));
    matchHeader.appendChild(el("span", "", match.score + "% match"));
    matchCard.appendChild(matchHeader);
    matchCard.appendChild(el("div", "meta", match.item.type.toUpperCase() + " | " + match.item.location + " | " +
      fmt(match.item.date) + " | " + match.item.reporter.name));
    const scoreBar = el("div", "bar");
    const scoreFill = el("span", match.score >= 60 ? "" : "mid");
    scoreFill.style.width = match.score + "%";
    scoreBar.appendChild(scoreFill);
    matchCard.appendChild(scoreBar);
    const lostReport = report.type === "lost" ? report : match.item;
    const foundReport = report.type === "found" ? report : match.item;
    const comparison = el("div", "match-compare");
    renderComparisonSide(comparison, lostReport, "Lost report");
    renderComparisonSide(comparison, foundReport, "Found report");
    matchCard.appendChild(comparison);
    const notifyButton = el("button", "", "Notify owner of the lost report");
    notifyButton.addEventListener("click", () => notifyLostReportOwner(lostReport, foundReport, match.score));
    matchCard.appendChild(notifyButton);
    dialog.appendChild(matchCard);
  });
}
