/* Admin conversation view and replies */
function renderMessages(dialog, report) {
  dialog.appendChild(el("h3", "", "Messages"));
  dialog.appendChild(thread(report));
  const replyInput = el("textarea");
  replyInput.rows = 2;
  replyInput.placeholder = "Reply to the student";
  const sendButton = el("button", "", "Send reply");
  sendButton.addEventListener("click", () => {
    const message = replyInput.value.trim();
    if (!message) return;
    report.messages.push({ from: "admin", text: message, at: new Date().toISOString() });
    save();
    openDetail(report.id, "message");
  });
  dialog.append(replyInput, sendButton);
}
