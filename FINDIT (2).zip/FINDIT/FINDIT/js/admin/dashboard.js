/* Admin login and dashboard list */
function login(e) {
  e.preventDefault();
  if ($("loginUser").value.trim() === ADMIN_USER && $("loginPass").value === ADMIN_PASS) {
    sessionStorage.setItem(SESSION, "1"); $("loginError").textContent = ""; $("loginPass").value = ""; show("admin");
  } else $("loginError").textContent = "Wrong username or password.";
}

function ageDays(i) { return Math.floor((Date.now() - new Date(i.date + "T00:00:00")) / 86400000); }
function renderAdmin() {
  const open = items.filter((i) => i.status !== "Claimed");
  const stats = $("stats"); stats.innerHTML = "";
  [["lost", open.filter((i) => i.type === "lost").length, "Open lost reports"], ["found", open.filter((i) => i.type === "found").length, "Found, waiting for owner"],
    ["claimed", items.length - open.length, "Claimed"], ["old", open.filter((i) => ageDays(i) >= 30).length, "Unclaimed 30+ days"]].forEach(([c, n, l]) => {
    const t = el("div", "tile " + c); t.appendChild(el("strong", "", String(n))); t.appendChild(el("span", "", l)); stats.appendChild(t); });
  const counts = { lost: items.filter((i) => i.type === "lost" && i.status !== "Claimed").length, found: items.filter((i) => i.type === "found" && i.status !== "Claimed").length,
    claimed: items.length - open.length, messages: items.filter((i) => i.messages.length).length,
    requests: items.filter((i) => i.deletionRequest && i.deletionRequest.status === "pending").length };
  document.querySelectorAll("#tabs button").forEach((b) => { b.classList.toggle("active", b.dataset.tab === tab);
    const label = b.dataset.tab === "requests" ? "Deletion requests" : b.dataset.tab[0].toUpperCase() + b.dataset.tab.slice(1);
    b.textContent = label + " (" + counts[b.dataset.tab] + ")"; });
  const q = $("search").value.trim().toLowerCase();
  const list = items.filter((i) => (tab === "requests" ? i.deletionRequest && i.deletionRequest.status === "pending" :
    tab === "messages" ? i.messages.length > 0 : tab === "claimed" ? i.status === "Claimed" : i.type === tab && i.status !== "Claimed") &&
    (q === "" || (i.name + " " + i.ref + " " + i.reporter.name + " " + i.reporter.sid + " " + i.description).toLowerCase().includes(q)) &&
    ($("fCategory").value === "" || i.category === $("fCategory").value) && ($("fLocation").value === "" || i.location === $("fLocation").value));
  const sort = $("sortBy").value;
  list.sort((a, b) => sort === "name" ? a.name.localeCompare(b.name) : sort === "oldest" ? a.id - b.id : b.id - a.id);
  $("count").textContent = "Showing " + list.length + " report" + (list.length === 1 ? "" : "s");
  const feed = $("feed"); feed.innerHTML = "";
  if (!list.length) feed.appendChild(el("div", "empty", "Nothing to show here."));
  list.forEach((i) => feed.appendChild(card(i)));
}

function refreshAdminFromStorage() {
  const d = $("detail"), id = d.open ? Number(d.dataset.itemId) : 0;
  const section = d.dataset.detailSection || "view";
  renderAdmin();
  if (id && items.some((item) => item.id === id)) openDetail(id, section);
  else if (d.open) d.close();
}

function card(i) {
  const c = el("article", "card" + (i.status === "Claimed" ? " claimed" : ""));
  const top = el("div", "card-top"); top.appendChild(el("span", "badge " + (i.status === "Claimed" ? "claimed" : i.type), i.status === "Claimed" ? "CLAIMED" : i.type.toUpperCase()));
  top.appendChild(el("h3", "", i.name)); if (i.unread) top.appendChild(el("span", "dot")); if (i.status !== "Claimed" && ageDays(i) >= 30) top.appendChild(el("span", "badge stale", "30+ DAYS"));
  c.appendChild(top);
  if (i.photo) { const im = el("img", "thumb"); im.src = i.photo; im.alt = ""; c.appendChild(im); }
  c.appendChild(el("div", "meta", i.ref + " | " + i.category + " | " + i.location + " | " + fmt(i.date)));
  c.appendChild(el("div", "meta", "Reporter: " + i.reporter.name + " (" + i.reporter.sid + ", " + i.reporter.dept + " " + i.reporter.block + ")"));
  c.appendChild(el("div", "custody", "Status: " + i.status + (i.custody ? " | Held at " + i.custody : "")));
  const actions = el("div", "card-actions");
  [["View", "view"], ["Matches", "matches"], ["Message", "message"]].forEach(([label, section]) => {
    const button = el("button", section === "view" ? "primary" : "", label);
    button.dataset.itemId = i.id;
    button.dataset.detailSection = section;
    actions.appendChild(button);
  });
  c.appendChild(actions);
  return c;
}
